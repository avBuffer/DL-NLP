var classfasttext_1_1Matrix =
[
    [ "Matrix", "classfasttext_1_1Matrix.html#ae3eed8f78b046582d6504eaae17b9890", null ],
    [ "Matrix", "classfasttext_1_1Matrix.html#adb3094376193874860df45e9346eebd6", null ],
    [ "Matrix", "classfasttext_1_1Matrix.html#ad70f2182e0dd1b520ee42200e2d0ed04", null ],
    [ "~Matrix", "classfasttext_1_1Matrix.html#ad4442ecc4c59f34e8d83b0ce87472417", null ],
    [ "addRow", "classfasttext_1_1Matrix.html#aceef1bc55d67b38c8b2b2c9ba7e769de", null ],
    [ "at", "classfasttext_1_1Matrix.html#afc9c477f90e9d9a193e1710e46a68221", null ],
    [ "at", "classfasttext_1_1Matrix.html#abb6222f956da7e32391092158eaaf5a0", null ],
    [ "divideRow", "classfasttext_1_1Matrix.html#ab4d6dd58db43dd2c4a6fbb12c74541a0", null ],
    [ "dotRow", "classfasttext_1_1Matrix.html#ae6b962ed2ca31fb3a8d094c8f85d6136", null ],
    [ "l2NormRow", "classfasttext_1_1Matrix.html#aa61bc6b1a1b2467d7fb41a9e99d96922", null ],
    [ "l2NormRow", "classfasttext_1_1Matrix.html#afb690a9d64bc7e941cbd48f20cab872e", null ],
    [ "load", "classfasttext_1_1Matrix.html#a8a04afebc25fcf38376f272371e0b60d", null ],
    [ "multiplyRow", "classfasttext_1_1Matrix.html#a103b48301d251f8af69409c123435b3c", null ],
    [ "operator=", "classfasttext_1_1Matrix.html#abe27a5e1c276ab145297c4941cd468f3", null ],
    [ "save", "classfasttext_1_1Matrix.html#aaf869b3115a6b404c13f5c31678c147b", null ],
    [ "uniform", "classfasttext_1_1Matrix.html#aef334e5d5a164b01c2b74960ffa3782d", null ],
    [ "zero", "classfasttext_1_1Matrix.html#a44eee2d614a0cce8396cd33ecb7439ba", null ],
    [ "data_", "classfasttext_1_1Matrix.html#a3a63d6e3e3db63e5f756bbc4692a46ae", null ],
    [ "m_", "classfasttext_1_1Matrix.html#adbdd245dfc806fbbbef33a07e4805084", null ],
    [ "n_", "classfasttext_1_1Matrix.html#aeeddaea318709ea37127caae30194ff3", null ]
];