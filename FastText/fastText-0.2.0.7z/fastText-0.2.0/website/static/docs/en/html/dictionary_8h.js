var dictionary_8h =
[
    [ "entry", "structfasttext_1_1entry.html", "structfasttext_1_1entry" ],
    [ "Dictionary", "classfasttext_1_1Dictionary.html", "classfasttext_1_1Dictionary" ],
    [ "id_type", "dictionary_8h.html#a6778f74ca8c360ba917216cb7fcbf497", null ],
    [ "entry_type", "dictionary_8h.html#a532eedeee97e8d66a96b519d165f4eb7", [
      [ "word", "dictionary_8h.html#a532eedeee97e8d66a96b519d165f4eb7ac47d187067c6cf953245f128b5fde62a", null ],
      [ "label", "dictionary_8h.html#a532eedeee97e8d66a96b519d165f4eb7ad304ba20e96d87411588eeabac850e34", null ]
    ] ]
];