var searchData=
[
  ['id_5ftype',['id_type',['../namespacefasttext.html#a6778f74ca8c360ba917216cb7fcbf497',1,'fasttext']]],
  ['initlog',['initLog',['../classfasttext_1_1Model.html#abf8bafb8fc35c220bf961893bf459c07',1,'fasttext::Model']]],
  ['initngrams',['initNgrams',['../classfasttext_1_1Dictionary.html#ab415b87adacc7d1570f8e2f630fe45c1',1,'fasttext::Dictionary']]],
  ['initsigmoid',['initSigmoid',['../classfasttext_1_1Model.html#ab64ec566b2fc836050ef178ec11df780',1,'fasttext::Model']]],
  ['inittablediscard',['initTableDiscard',['../classfasttext_1_1Dictionary.html#aaa2d7d0ccde56223a3088594651e782e',1,'fasttext::Dictionary']]],
  ['inittablenegatives',['initTableNegatives',['../classfasttext_1_1Model.html#a03859cabcddafddfdb7e6d8862e2ae6c',1,'fasttext::Model']]],
  ['input',['input',['../classfasttext_1_1Args.html#a6377f6e903dd4f991ffd477a7a4392dd',1,'fasttext::Args']]],
  ['input_5f',['input_',['../classfasttext_1_1FastText.html#aa25683f12eed057c159fd11fd3a55efb',1,'fasttext::FastText']]]
];
