var searchData=
[
  ['qinput_5f',['qinput_',['../classfasttext_1_1FastText.html#aa4f1d5f2269feee25ae8119bc8e778c4',1,'fasttext::FastText']]],
  ['qmatrix',['QMatrix',['../classfasttext_1_1QMatrix.html',1,'fasttext::QMatrix'],['../classfasttext_1_1QMatrix.html#a976442aaed5b1afee2f2cd4473c0d62b',1,'fasttext::QMatrix::QMatrix()'],['../classfasttext_1_1QMatrix.html#ae10f3f12bf4c8483381ecb122b7fda5a',1,'fasttext::QMatrix::QMatrix(const Matrix &amp;, int32_t, bool)']]],
  ['qmatrix_2ecc',['qmatrix.cc',['../qmatrix_8cc.html',1,'']]],
  ['qmatrix_2eh',['qmatrix.h',['../qmatrix_8h.html',1,'']]],
  ['qnorm',['qnorm',['../classfasttext_1_1Args.html#a1926c846b30e99f825a90948faba145f',1,'fasttext::Args']]],
  ['qnorm_5f',['qnorm_',['../classfasttext_1_1QMatrix.html#aadc6e4d399442555f3c2993b97285143',1,'fasttext::QMatrix']]],
  ['qout',['qout',['../classfasttext_1_1Args.html#ac689f4264b24814541bee8b5cf3abbcc',1,'fasttext::Args']]],
  ['qoutput_5f',['qoutput_',['../classfasttext_1_1FastText.html#a62ad59060370a16588e407ce3ffebfaa',1,'fasttext::FastText']]],
  ['quant_5f',['quant_',['../classfasttext_1_1FastText.html#aeb75b28c20c01110cfcf807a518076c8',1,'fasttext::FastText::quant_()'],['../classfasttext_1_1Model.html#a0d3b51a1c171314b879aae52c3717a43',1,'fasttext::Model::quant_()']]],
  ['quantize',['quantize',['../classfasttext_1_1FastText.html#aa01f053de2afa22056c594d96988c1ad',1,'fasttext::FastText::quantize()'],['../classfasttext_1_1QMatrix.html#ab9ae1914dc1b72e305880a8c22626afc',1,'fasttext::QMatrix::quantize()'],['../main_8cc.html#a6e07bb2da057cf6a518eed616b490bdd',1,'quantize():&#160;main.cc']]],
  ['quantizenorm',['quantizeNorm',['../classfasttext_1_1QMatrix.html#a0e4d84be1c6cd0cbfc4568f905961017',1,'fasttext::QMatrix']]],
  ['qwi_5f',['qwi_',['../classfasttext_1_1Model.html#ac9524ea5200abefdd2d83e29ffaa9693',1,'fasttext::Model']]],
  ['qwo_5f',['qwo_',['../classfasttext_1_1Model.html#a4ee087454e830b18c22a59ae9bb6fcf1',1,'fasttext::Model']]]
];
