var searchData=
[
  ['matrix',['Matrix',['../classfasttext_1_1Matrix.html',1,'fasttext']]],
  ['model',['Model',['../classfasttext_1_1Model.html',1,'fasttext']]]
];
