var searchData=
[
  ['save',['save',['../classfasttext_1_1Args.html#ae843bd7c49e9fd34220af65f19df7392',1,'fasttext::Args::save()'],['../classfasttext_1_1Dictionary.html#a5bff16d3407dc293912fb9fa56f6162b',1,'fasttext::Dictionary::save()'],['../classfasttext_1_1Matrix.html#aaf869b3115a6b404c13f5c31678c147b',1,'fasttext::Matrix::save()'],['../classfasttext_1_1ProductQuantizer.html#a6e4d58883fb38225c6f4731770b89274',1,'fasttext::ProductQuantizer::save()'],['../classfasttext_1_1QMatrix.html#a00267b43ee5eefc92948c654fb9fc9f1',1,'fasttext::QMatrix::save()']]],
  ['savemodel',['saveModel',['../classfasttext_1_1FastText.html#a3bc5bf68cf6e1f487fa57ddc750f2099',1,'fasttext::FastText']]],
  ['saveoutput',['saveOutput',['../classfasttext_1_1FastText.html#adbe7666386c0d7cb9017fa641e391b9f',1,'fasttext::FastText']]],
  ['savevectors',['saveVectors',['../classfasttext_1_1FastText.html#a64fc781f7e3e60a3794562a03477398f',1,'fasttext::FastText']]],
  ['seek',['seek',['../namespacefasttext_1_1utils.html#a9d7d5c4b31752c7fe0bf71970203f82d',1,'fasttext::utils']]],
  ['selectembeddings',['selectEmbeddings',['../classfasttext_1_1FastText.html#a06fbfe68049942cab56eb85ebb2ca4d9',1,'fasttext::FastText']]],
  ['sentencevectors',['sentenceVectors',['../classfasttext_1_1FastText.html#a39efb50f61237890cbf2e30b7a516618',1,'fasttext::FastText']]],
  ['setquantizepointer',['setQuantizePointer',['../classfasttext_1_1Model.html#adb25aef3feb355ebf781e104e3065713',1,'fasttext::Model']]],
  ['settargetcounts',['setTargetCounts',['../classfasttext_1_1Model.html#a8026fcbe9d5b566ab5ca97e104512f0b',1,'fasttext::Model']]],
  ['sigmoid',['sigmoid',['../classfasttext_1_1Model.html#a408d1426eb8aaf78a873bb4edd7d7dbf',1,'fasttext::Model']]],
  ['signmodel',['signModel',['../classfasttext_1_1FastText.html#afe7b85dd466c4ccef45e4c590edae585',1,'fasttext::FastText']]],
  ['size',['size',['../classfasttext_1_1Vector.html#af3e8aa155da430d0911896d53db6789d',1,'fasttext::Vector::size()'],['../namespacefasttext_1_1utils.html#a2d7a0a4c572dbfa5458ca782355c35aa',1,'fasttext::utils::size()']]],
  ['skipgram',['skipgram',['../classfasttext_1_1FastText.html#aa1855802a2a1f2f1398fdad79f73b66a',1,'fasttext::FastText']]],
  ['softmax',['softmax',['../classfasttext_1_1Model.html#aded1fd701066b50be1e74f64d5b81a0e',1,'fasttext::Model']]],
  ['supervised',['supervised',['../classfasttext_1_1FastText.html#a3c56524cdccf6f9d23b75460bbea5d5f',1,'fasttext::FastText']]]
];
