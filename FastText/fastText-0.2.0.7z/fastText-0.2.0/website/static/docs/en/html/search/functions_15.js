var searchData=
[
  ['wordvectors',['wordVectors',['../classfasttext_1_1FastText.html#a1a5d918e595e00a8ea7b9bc5ac8f6c35',1,'fasttext::FastText']]]
];
