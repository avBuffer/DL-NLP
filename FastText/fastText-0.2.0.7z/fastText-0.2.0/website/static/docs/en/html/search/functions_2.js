var searchData=
[
  ['cbow',['cbow',['../classfasttext_1_1FastText.html#a592036d3a8ae545637db4864dbe5274f',1,'fasttext::FastText']]],
  ['checkmodel',['checkModel',['../classfasttext_1_1FastText.html#a7a874ab83984dc05dca56a74edae25c1',1,'fasttext::FastText']]],
  ['comparepairs',['comparePairs',['../classfasttext_1_1Model.html#ac475c67452b62dd374b6253f99167816',1,'fasttext::Model']]],
  ['compute_5fcode',['compute_code',['../classfasttext_1_1ProductQuantizer.html#a1b6fedf0a199ed0ec1afc2aea26a4b37',1,'fasttext::ProductQuantizer']]],
  ['compute_5fcodes',['compute_codes',['../classfasttext_1_1ProductQuantizer.html#aca0eb5cd10d5bba60b4f3f37f87676f6',1,'fasttext::ProductQuantizer']]],
  ['computehidden',['computeHidden',['../classfasttext_1_1Model.html#ae561523a8c81dd60d9bbe10336f83110',1,'fasttext::Model']]],
  ['computeoutputsoftmax',['computeOutputSoftmax',['../classfasttext_1_1Model.html#a00f5b7ed6e10c2bafa29919136c471f6',1,'fasttext::Model::computeOutputSoftmax(Vector &amp;, Vector &amp;) const'],['../classfasttext_1_1Model.html#af48ca152068185f0bd31746be56c03bd',1,'fasttext::Model::computeOutputSoftmax()']]],
  ['computesubwords',['computeSubwords',['../classfasttext_1_1Dictionary.html#ac175ccc5be52cd4b048c7ef4e1fa316e',1,'fasttext::Dictionary::computeSubwords(const std::string &amp;, std::vector&lt; int32_t &gt; &amp;) const'],['../classfasttext_1_1Dictionary.html#a1af5a16259f201bb08819cc2de938ecf',1,'fasttext::Dictionary::computeSubwords(const std::string &amp;, std::vector&lt; int32_t &gt; &amp;, std::vector&lt; std::string &gt; &amp;) const']]]
];
